// Illustrative placeholders. These are NOT real Reddit posts or scraped content.
const examples = [
  { topic: 'space', title: 'A quiet corner of the cosmos', author: 'sample', score: 2400, comments: 86, art: 'space', domain: 'sample.local' },
  { topic: 'aviation', title: 'Above the clouds, just before sunset', author: 'sample', score: 1800, comments: 42, art: 'flight', domain: 'sample.local' },
  { topic: 'science', title: 'The beauty of asking better questions', author: 'sample', score: 910, comments: 64, art: 'science', domain: 'sample.local' },
  { topic: 'technology', title: 'Small circuits, big ideas', author: 'sample', score: 1500, comments: 132, art: 'circuit', domain: 'sample.local' },
  { topic: 'EarthPorn', title: 'Somewhere worth turning your phone off', author: 'sample', score: 4200, comments: 105, art: 'nature', domain: 'sample.local' },
  { topic: 'personalfinance', title: 'Thinking about the long game', author: 'sample', score: 784, comments: 57, art: 'finance', domain: 'sample.local' },
  { topic: 'MachineLearning', title: 'The next frontier is still being drawn', author: 'sample', score: 329, comments: 27, art: 'circuit', domain: 'sample.local' },
  { topic: 'pics', title: 'After the rain, the world looks different', author: 'sample', score: 1200, comments: 31, art: 'nature', domain: 'sample.local' },
  { topic: 'spaceporn', title: 'Night sky over a distant horizon', author: 'sample', score: 1900, comments: 68, art: 'space', domain: 'sample.local' },
  { topic: 'flying', title: 'Why we keep looking up', author: 'sample', score: 621, comments: 43, art: 'flight', domain: 'sample.local' }
];
export function samplesFor(subs) {
  const lookup = new Set(subs.map(s => s.toLowerCase()));
  const matches = examples.filter(post => lookup.has(post.topic.toLowerCase()));
  const items = matches.length ? matches : subs.map((subreddit, i) => ({ ...examples[i % examples.length], topic: subreddit }));
  return items.map((p, i) => ({
    id: `sample-${i}`, subreddit: p.topic, title: p.title, author: p.author,
    score: p.score, comments: p.comments, createdUtc: Date.now() / 1000 - (i + 1) * 3500,
    image: `/assets/${p.art}.svg`, video: null, isVideo: false, nsfw: false,
    spoiler: false, url: `https://www.reddit.com/r/${encodeURIComponent(p.topic)}/`,
    text: 'Illustrative preview only. Connect an approved Reddit API application to load actual posts.',
    domain: 'sample.local', isSample: true
  }));
}
