import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeListing, normalizePost, normalizeSubreddits, safePeriod, safeSort } from '../core.js';

test('subreddit input is validated, capped and deduplicated', () => {
  assert.deepEqual(normalizeSubreddits('r/science,Science, r/space,../secrets,ok'), ['science','space','ok']);
  assert.equal(normalizeSubreddits(Array.from({length:20}, (_,i)=>`sub${i}`)).length, 12);
});
test('sort and period reject unknown values', () => {
  assert.equal(safeSort('evil'), 'hot');
  assert.equal(safePeriod('day'), 'day');
  assert.equal(safePeriod('invalid'), 'week');
});
test('reddit listing normalization handles encoded image, video and pagination', () => {
  const raw = { kind: 't3', data: { name: 't3_ab1', title: 'Example', subreddit: 'space', permalink: '/r/space/comments/ab1/example/', preview: { images: [{ source: { url: 'https://preview.redd.it/x.jpg?x=1&amp;y=2' } }] }, secure_media: { reddit_video: { fallback_url: 'https://v.redd.it/demo/DASH_720.mp4' } } } };
  const result = normalizeListing({ data: { children: [raw], after: 't3_ab1' } });
  assert.equal(result.posts.length, 1);
  assert.equal(result.posts[0].image, 'https://preview.redd.it/x.jpg?x=1&y=2');
  assert.ok(result.posts[0].video.includes('v.redd.it'));
  assert.equal(result.after, 't3_ab1');
});
test('invalid URLs are excluded and only Reddit permalinks are accepted', () => {
  const post = normalizePost({data:{title:'X',permalink:'https://evil.example/', thumbnail:'javascript:alert(1)',secure_media:{reddit_video:{fallback_url:'http://insecure/video.mp4'}}}});
  assert.equal(post.url, 'https://www.reddit.com/');
  assert.equal(post.image, null);
  assert.equal(post.video, null);
});
