import test from 'node:test';
import assert from 'node:assert/strict';
import { server } from '../server.js';

test('HTTP server serves app and reports OAuth status without revealing credentials', async () => {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  try {
    const status = await fetch(base + '/api/status');
    const body = await status.json();
    assert.equal(status.status, 200);
    assert.equal(typeof body.configured, 'boolean');
    assert.equal(typeof body.authenticated, 'boolean');
    assert.equal(Object.hasOwn(body, 'clientSecret'), false);
    const home = await fetch(base + '/');
    assert.equal(home.status, 200);
    assert.match(await home.text(), /MultiFeed/);
    const unauthorized = await fetch(base + '/api/feed?subs=science');
    assert.ok([401,503].includes(unauthorized.status));
    const wrongMethod = await fetch(base + '/api/status', {method:'POST'});
    assert.equal(wrongMethod.status, 405);
  } finally {
    await new Promise(resolve => server.close(resolve));
  }
});
