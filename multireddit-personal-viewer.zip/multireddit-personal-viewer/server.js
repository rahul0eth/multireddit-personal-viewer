import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { normalizeSubreddits, normalizeListing, safePeriod, safeSort } from './core.js';

const root = path.dirname(fileURLToPath(import.meta.url));
const envFile = path.join(root, '.env');
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const match = /^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)?$/.exec(line);
    if (match && !Object.hasOwn(process.env, match[1])) process.env[match[1]] = (match[2] || '').trim().replace(/^['"]|['"]$/g, '');
  }
}
const PORT = Number(process.env.PORT || 8787);
const clientId = process.env.REDDIT_CLIENT_ID;
const clientSecret = process.env.REDDIT_CLIENT_SECRET;
const redirectUri = process.env.REDDIT_REDIRECT_URI || `http://localhost:${PORT}/auth/callback`;
const sessionSecret = process.env.SESSION_SECRET || '';
const configured = Boolean(clientId && clientSecret && sessionSecret.length >= 24);
const cookieSecure = redirectUri.startsWith('https:');
const sessions = new Map();
const userAgent = 'web:multireddit-personal-viewer:0.1.0 (by /u/delhibuoy)';

function cookie(name, value, maxAge = 604800) {
  return `${name}=${encodeURIComponent(value)}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${maxAge}${cookieSecure ? '; Secure' : ''}`;
}
function parseCookie(req, name) {
  const found = (req.headers.cookie || '').split(';').map(s => s.trim()).find(s => s.startsWith(`${name}=`));
  if (!found) return '';
  try { return decodeURIComponent(found.slice(name.length + 1)); } catch { return ''; }
}
function sign(value) { return `${value}.${crypto.createHmac('sha256', sessionSecret).update(value).digest('hex')}`; }
function verify(signed) {
  const i = signed.lastIndexOf('.');
  if (i < 1) return '';
  const value = signed.slice(0, i);
  const expected = Buffer.from(sign(value));
  const received = Buffer.from(signed);
  return expected.length === received.length && crypto.timingSafeEqual(expected, received) ? value : '';
}
function respond(res, status, data, headers = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...headers });
  res.end(JSON.stringify(data));
}
function redirect(res, location, headers = {}) { res.writeHead(302, { Location: location, ...headers }); res.end(); }
function sessionFor(req) { return sessions.get(verify(parseCookie(req, 'multi_session'))); }
function errorText(status) {
  if (status === 401 || status === 403) return 'Reddit rejected this authorization. Reconnect or check API approval.';
  if (status === 429) return 'Reddit rate limit reached. Try again later.';
  return `Reddit API returned HTTP ${status}.`;
}
async function tokenRequest(params) {
  const auth = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
  const response = await fetch('https://www.reddit.com/api/v1/access_token', {
    method: 'POST', headers: { Authorization: `Basic ${auth}`, 'User-Agent': userAgent, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(params), signal: AbortSignal.timeout(12000)
  });
  const value = await response.json();
  if (!response.ok || !value.access_token) throw new Error(errorText(response.status));
  return value;
}
async function activeToken(session) {
  if (Date.now() < session.expiresAt - 60_000) return session.accessToken;
  if (!session.refreshToken) throw new Error('Session expired. Sign in again.');
  const token = await tokenRequest({ grant_type: 'refresh_token', refresh_token: session.refreshToken });
  session.accessToken = token.access_token;
  session.expiresAt = Date.now() + (token.expires_in || 3600) * 1000;
  if (token.refresh_token) session.refreshToken = token.refresh_token;
  return session.accessToken;
}
async function api(req, res, url) {
  if (url.pathname === '/api/status') {
    return respond(res, 200, { configured, authenticated: configured && Boolean(sessionFor(req)) });
  }
  if (url.pathname === '/api/feed') {
    if (!configured) return respond(res, 503, { error: 'No approved Reddit API credentials configured. Demo mode is available.' });
    const session = sessionFor(req);
    if (!session) return respond(res, 401, { error: 'Sign in to Reddit to load posts.' });
    const subs = normalizeSubreddits(url.searchParams.get('subs'));
    if (!subs.length) return respond(res, 400, { error: 'Add at least one valid subreddit.' });
    const sort = safeSort(url.searchParams.get('sort'));
    const period = safePeriod(url.searchParams.get('period'));
    const after = url.searchParams.get('after') || '';
    if (after && !/^t3_[a-z0-9]+$/i.test(after)) return respond(res, 400, { error: 'Invalid cursor.' });
    const redditUrl = new URL(`https://oauth.reddit.com/r/${subs.join('+')}/${sort}`);
    redditUrl.search = new URLSearchParams({ raw_json: '1', limit: '40', ...(sort === 'top' ? { t: period } : {}), ...(after ? { after } : {}) }).toString();
    try {
      const token = await activeToken(session);
      const upstream = await fetch(redditUrl, { headers: { Authorization: `Bearer ${token}`, 'User-Agent': userAgent }, signal: AbortSignal.timeout(15000) });
      if (!upstream.ok) return respond(res, upstream.status, { error: errorText(upstream.status) });
      return respond(res, 200, normalizeListing(await upstream.json()));
    } catch (err) { return respond(res, 502, { error: err.message || 'Unable to contact Reddit.' }); }
  }
  return respond(res, 404, { error: 'Not found' });
}
function serveStatic(res, pathname) {
  const file = pathname === '/' ? 'index.html' : pathname.slice(1);
  const resolved = path.resolve(root, 'public', file);
  const publicRoot = path.resolve(root, 'public');
  if (!resolved.startsWith(publicRoot + path.sep) && resolved !== path.join(publicRoot, 'index.html')) return respond(res, 404, { error: 'Not found' });
  const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon' };
  fs.readFile(resolved, (err, content) => {
    if (err) return respond(res, 404, { error: 'Not found' });
    res.writeHead(200, { 'Content-Type': types[path.extname(resolved)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-cache', 'Content-Security-Policy': "default-src 'self'; img-src 'self' https: data:; media-src 'self' https:; connect-src 'self'; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self' https://www.reddit.com;" });
    res.end(content);
  });
}
export const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  if (req.method !== 'GET') return respond(res, 405, { error: 'Method not allowed' });
  if (url.pathname.startsWith('/api/')) return api(req, res, url);
  if (url.pathname === '/auth/reddit') {
    if (!configured) return redirect(res, '/?error=credentials');
    const state = crypto.randomBytes(24).toString('hex');
    const authUrl = new URL('https://www.reddit.com/api/v1/authorize');
    authUrl.search = new URLSearchParams({ client_id: clientId, response_type: 'code', state, redirect_uri: redirectUri, duration: 'permanent', scope: 'read identity' }).toString();
    return redirect(res, authUrl.href, { 'Set-Cookie': cookie('multi_oauth_state', sign(state), 600) });
  }
  if (url.pathname === '/auth/callback') {
    if (!configured) return redirect(res, '/?error=credentials');
    const original = verify(parseCookie(req, 'multi_oauth_state'));
    res.setHeader('Set-Cookie', cookie('multi_oauth_state', '', 0));
    if (!original || url.searchParams.get('state') !== original || !url.searchParams.get('code')) return redirect(res, '/?error=oauth');
    try {
      const token = await tokenRequest({ grant_type: 'authorization_code', code: url.searchParams.get('code'), redirect_uri: redirectUri });
      const id = crypto.randomBytes(32).toString('hex');
      sessions.set(id, { accessToken: token.access_token, refreshToken: token.refresh_token, expiresAt: Date.now() + (token.expires_in || 3600) * 1000 });
      return redirect(res, '/', { 'Set-Cookie': [cookie('multi_oauth_state', '', 0), cookie('multi_session', sign(id))] });
    } catch { return redirect(res, '/?error=oauth'); }
  }
  if (url.pathname === '/auth/logout') {
    const id = verify(parseCookie(req, 'multi_session'));
    if (id) sessions.delete(id);
    return redirect(res, '/', { 'Set-Cookie': cookie('multi_session', '', 0) });
  }
  return serveStatic(res, url.pathname);
});
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  server.listen(PORT, '127.0.0.1', () => console.log(`MultiFeed running at http://localhost:${PORT} (${configured ? 'Reddit OAuth enabled' : 'demo mode'})`));
}
