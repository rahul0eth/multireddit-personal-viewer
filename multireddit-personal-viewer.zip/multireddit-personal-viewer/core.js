/** Pure helpers shared with the HTTP server and regression tests. */
export function normalizeSubreddits(input) {
  const values = Array.isArray(input) ? input : String(input || '').split(',');
  const output = [];
  for (const raw of values) {
    const name = String(raw).trim().replace(/^\/?r\//i, '');
    if (!/^[a-zA-Z0-9_]{2,21}$/.test(name)) continue;
    if (!output.some(value => value.toLowerCase() === name.toLowerCase())) output.push(name);
    if (output.length === 12) break;
  }
  return output;
}

export function safeSort(sort) {
  return ['hot', 'new', 'top', 'rising'].includes(sort) ? sort : 'hot';
}
export function safePeriod(period) {
  return ['hour', 'day', 'week', 'month', 'year', 'all'].includes(period) ? period : 'week';
}

function httpsMedia(url) {
  if (typeof url !== 'string' || !url) return null;
  try {
    const parsed = new URL(url.replaceAll('&amp;', '&'));
    return parsed.protocol === 'https:' ? parsed.href : null;
  } catch { return null; }
}

export function normalizePost(item) {
  const p = item?.data || {};
  const preview = p.preview?.images?.[0]?.source?.url;
  const direct = /\.(?:jpe?g|png|webp|gif)(?:\?.*)?$/i.test(p.url_overridden_by_dest || '')
    ? p.url_overridden_by_dest : null;
  const galleryId = p.gallery_data?.items?.[0]?.media_id;
  const gallery = galleryId ? p.media_metadata?.[galleryId]?.s?.u : null;
  const video = httpsMedia(p.secure_media?.reddit_video?.fallback_url || p.media?.reddit_video?.fallback_url);
  const image = httpsMedia(direct || gallery || preview || p.thumbnail);
  const permalink = typeof p.permalink === 'string' && /^\/r\/[\w]+\/comments\//.test(p.permalink)
    ? `https://www.reddit.com${p.permalink}` : 'https://www.reddit.com/';
  return {
    id: String(p.name || p.id || ''),
    title: String(p.title || 'Untitled').slice(0, 500),
    subreddit: String(p.subreddit || ''),
    author: String(p.author || ''),
    score: Number(p.score) || 0,
    comments: Number(p.num_comments) || 0,
    createdUtc: Number(p.created_utc) || 0,
    nsfw: Boolean(p.over_18),
    spoiler: Boolean(p.spoiler),
    image,
    video,
    url: permalink,
    isVideo: Boolean(video),
    domain: String(p.domain || ''),
    text: String(p.selftext || '').slice(0, 350)
  };
}

export function normalizeListing(payload) {
  const data = payload?.data || {};
  if (!Array.isArray(data.children)) throw new Error('Unexpected Reddit response');
  return {
    posts: data.children.filter(item => item?.kind === 't3').map(normalizePost),
    after: typeof data.after === 'string' && /^t3_[a-z0-9]+$/i.test(data.after) ? data.after : null
  };
}
