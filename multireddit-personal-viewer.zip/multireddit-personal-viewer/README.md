# MultiFeed

A personal, noncommercial, read-only multireddit viewer designed for media browsing. Combine selected subreddits, switch between a responsive grid and a full-screen vertical media viewer, and save feed presets locally.

> **Status:** Working local prototype. The sample feed runs without credentials. **Real Reddit posts require an approved Reddit Data API application.** This project does not scrape Reddit or work around API approval, and it is not affiliated with Reddit.

## Features

- Create and manage custom subreddit mixes, stored in your browser's local storage.
- Hot / New / Top sorting; time range for Top.
- Photo/video grid and full-screen vertical media viewer, with keyboard controls (J/K or arrows, Escape).
- Optional media-only filter and NSFW exclusion enabled by default.
- Open any real post on Reddit; no automated posting, voting, or commenting.
- Server-side Reddit OAuth with minimal `read identity` scopes, secure HttpOnly sessions, and no credentials exposed to browser code.
- Zero external Node dependencies.

## Quick start

Requirements: Node.js 20+.

```bash
npm start
```

Open [http://localhost:8787](http://localhost:8787). No key is needed for the clearly labeled **sample mode**. The sample cards are illustrative mock data, not Reddit content.

## Connect Reddit (approval required)

1. Request Reddit API access through [Reddit Help](https://support.reddithelp.com/hc/en-us/requests/new?ticket_form_id=14868593862164). Explain the read-only, personal use case and why a stand-alone browser viewer is not supported by Devvit.
2. After approval, register/configure a Reddit **web app** with a callback of `http://localhost:8787/auth/callback`. Copy `.env.example` to `.env` and set `REDDIT_CLIENT_ID`, `REDDIT_CLIENT_SECRET`, and a random `SESSION_SECRET` (at least 24 characters).
3. Run `npm start`, click **Connect Reddit**, and sign in using your Reddit account. Posts will load through the authorized OAuth API only.

Reddit may not approve this use case and is retiring legacy Public Data API access. This is an integration scaffold, **not** a guarantee of continued API availability. Review [Reddit's developer policy](https://redditinc.com/policies/developer-terms) and [migration guidance](https://developers.reddit.com/docs/guides/migrate/public-api) before relying on it.

## API endpoints

| Route | Purpose |
|---|---|
| `GET /api/status` | OAuth configuration and current session state |
| `GET /auth/reddit` | OAuth authorization with `read identity` scopes |
| `GET /auth/callback` | OAuth code exchange (server-side) |
| `GET /auth/logout` | Clear in-memory session |
| `GET /api/feed?subs=science,space&sort=top&period=week` | Paginated authorized Reddit listing |

## Security / privacy

- API tokens stay on the server, in memory only. Sessions disappear on restart.
- Tokens, client secrets, and `.env` are not committed. Never put API keys in client-side code.
- Bound to `127.0.0.1` by default. Do not expose this prototype to the public internet without production session storage, HTTPS, abuse controls, and a full security review.
- No telemetry or analytics. Browser local storage contains only your feed settings.
- No bulk download, automation, or model training. Reddit API errors are surfaced instead of silently replaced with scraped data.

## Development

```bash
npm test
npm run dev
```

## Project scope

Initial prototype for personal experimentation. No hosted service, monetization, Reddit content redistribution, or community bot behavior is planned.
